<div class="collapse" id="processMap">
    <div class="panel panel-primary pMap">
        <div class="panel-heading">
            <div class="pull-left">
                <h5><strong>Application Process Map</strong></h5>
            </div>
            <div class="pull-right">
                <b><h5 style="color: #ffff00" id="shortFall">The current status is "shortfall". Applicant has to
                        Re-submit again</h5></b>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="panel-body">
            <div class="text-center" id="map-loading">
                <br/>
                <br/>
                <i class="fa fa-spinner fa-pulse fa-4x"></i>
                <br/>
                <br/>
            </div>

            <svg width="100%" height="220">
                <g></g>
            </svg>
        </div>
    </div>
</div>

