<?php

use App\Libraries\CommonFunction;
use App\Libraries\Encryption;
use App\Libraries\UtilFunction;
use App\Modules\Apps\Models\Airports;
use App\Modules\BasicInformation\Models\BasicInformation;
use App\Modules\BidaRegistration\Controllers\BidaRegistrationController;
use App\Modules\BidaRegistration\Models\BidaRegistration;
use App\Modules\BidaRegistrationAmendment\Controllers\BidaRegistrationAmendmentController;
use App\Modules\BidaRegistrationAmendment\Models\BidaRegistrationAmendment;
use App\Modules\BoardMeting\Models\BoardMeting;
use App\Modules\IrcRecommendationNew\Models\InspectionAnnualProduction;
use App\Modules\IrcRecommendationNew\Models\IrcInspection;
use App\Modules\IrcRecommendationNew\Models\IrcRecommendationNew;
use App\Modules\IrcRecommendationSecondAdhoc\Models\IrcRecommendationSecondAdhoc;
use App\Modules\IrcRecommendationSecondAdhoc\Models\SecondInspectionAnnualProduction;
use App\Modules\IrcRecommendationSecondAdhoc\Models\SecondIrcInspection;
use App\Modules\IrcRecommendationThirdAdhoc\Models\IrcRecommendationThirdAdhoc;
use App\Modules\IrcRecommendationThirdAdhoc\Models\ThirdInspectionAnnualProduction;
use App\Modules\IrcRecommendationThirdAdhoc\Models\ThirdIrcInspection;
use App\Modules\LicenceApplication\Controllers\BankAccountController;
use App\Modules\LicenceApplication\Controllers\CompanyRegistrationController;
use App\Modules\LicenceApplication\Controllers\EtinController;
use App\Modules\LicenceApplication\Controllers\NameClearanceController;
use App\Modules\OfficePermissionAmendment\Models\OfficePermissionAmendment;
use App\Modules\OfficePermissionCancellation\Models\OfficePermissionCancellation;
use App\Modules\OfficePermissionExtension\Models\OfficePermissionExtension;
use App\Modules\OfficePermissionNew\Models\OfficePermissionNew;
use App\Modules\ProcessPath\Models\ProcessList;
use App\Modules\ProcessPath\Services\IRCCommonPoolManager;
use App\Modules\ProcessPath\Services\OPCommonPoolManager;
use App\Modules\ProcessPath\Services\VRCommonPoolManager;
use App\Modules\ProcessPath\Services\WPCommonPoolManager;
use App\Modules\ProcessPath\Services\BRCommonPoolManager;
use App\Modules\Remittance\Models\Remittance;
use App\Modules\Settings\Models\HighComissions;
use App\Modules\Settings\Models\PdfPrintRequestQueue;
use App\Modules\Settings\Models\PdfServiceInfo;
use App\Modules\Settings\Models\Stakeholder;
use App\Modules\Users\Models\CompanyInfo;
use App\Modules\Users\Models\Users;
use App\Modules\VipLounge\Models\VipLounge;
use App\Modules\VisaRecommendation\Models\VisaRecommendation;
use App\Modules\VisaRecommendationAmendment\Models\VisaRecommendationAmendment;
use App\Modules\WorkPermitAmendment\Models\WorkPermitAmendment;
use App\Modules\WorkPermitCancellation\Models\WorkPermitCancellation;
use App\Modules\WorkPermitExtension\Models\WorkPermitExtension;
use App\Modules\WorkPermitNew\Models\WorkPermitNew;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

function getDataFromJson($json)
{
    $jsonDecoded = json_decode($json);
    $string = '';
    foreach ($jsonDecoded as $key => $data) {
        $string .= $key . ":" . $data . ', ';
    }
    return $string;
}


function getListDataFromJson($json, $company_name)
{
    $jsonDecoded = json_decode($json);
    $string = $company_name . '<br/>';
    /*
    Siraj vai feedback a ei requirement ti chaoya te company name ke JSON theke remove kore sob somoy update compnay name ke json a concate kore dekhano hoyeche
    Feedback referrence:
            Email Date: Thu, 12 Sep 2019 at 14:17
            Subject- Summary of testing report for 46 feedback in UAT
    */
    foreach ($jsonDecoded as $key => $data) {
        $string .= $key . ": " . $data . '<br/>';
    }
    return $string;
}

function getRating($list)
{
    $feedbackR = '';
    for ($i = 1; $i <= 5; $i++) {
        $color = '';
        if ($i == $list->rating) {
            $color = 'color: #DAC16C';
        }
        $title = '';
        switch ($i) {
            case 1:
                $title = 'Very poor';
                $img = '<img src="/assets/images/Feedbackimage/horrible.png" style="width: 100%" id="image_1">';
                if ($list->rating == 1) {
                    $img = '<img src="/assets/images/Feedbackimage/_horrible.png" style="width: 100%" id="image_1">';
                }
                break;
            case 2:
                $title = 'Poor';
                $img = '<img src="/assets/images/Feedbackimage/poor.png" style="width: 100%" id="image_1">';
                if ($list->rating == 2) {
                    $img = '<img src="/assets/images/Feedbackimage/_poor.png" style="width: 100%" id="image_1">';
                }
                break;
            case 3:
                $title = 'Average';
                $img = '<img src="/assets/images/Feedbackimage/averge.png" style="width: 100%" id="image_1">';
                if ($list->rating == 3) {
                    $img = '<img src="/assets/images/Feedbackimage/_averge.png" style="width: 100%" id="image_1">';
                }

                break;
            case 4:
                $title = 'Satisfied';
                $img = '<img src="/assets/images/Feedbackimage/good.png" style="width: 100%" id="image_1">';
                if ($list->rating == 4) {
                    $img = '<img src="/assets/images/Feedbackimage/_good.png" style="width: 100%" id="image_1">';
                }
                break;
            case 5:
                $title = 'Strongly Satisfied';
                $img = '<img src="/assets/images/Feedbackimage/excellent.png" style="width: 100%" id="image_1">';
                if ($list->rating == 5) {
                    $img = '<img src="/assets/images/Feedbackimage/_excellent.png" style="width: 100%" id="image_1">';
                }
                break;

            default:
                $title = 'something was wrong! ';
        }

        $feedbackR .= '<label   title="' . $title . '" class="pointer" style="cursor:pointer;font-size: 15px;width:40px; ' . $color . ' " >
        ' . $img . '
</label>';
    }
    $feedbackR .= '<br>' . $list->comment;
    return $feedbackR;
}

function CertificateMailOtherData($process_list_id, $status_id, $approver_desk_id = 0, $requestData)
{
    // Any customized code for different processType and status can be done in this function
    $process = ProcessList::leftJoin('process_type', 'process_type.id', '=', 'process_list.process_type_id')
        ->where('process_list.id', $process_list_id)
        ->first([
            'process_type.name as process_type_name',
            'process_type.process_supper_name',
            'process_type.process_sub_name',
            'process_list.*'
        ]);

    //  Get users email and phone no according to working company id
    $applicantEmailPhone = UtilFunction::geCompanyUsersEmailPhone($process->company_id);

    $appInfo = [
        'app_id' => $process->ref_id,
        'status_id' => $status_id,
        'process_type_id' => $process->process_type_id,
        'department_id' => $process->department_id,
        'tracking_no' => $process->tracking_no,
        'process_type_name' => $process->process_type_name,
        'process_supper_name' => $process->process_supper_name,
        'process_sub_name' => $process->process_sub_name,
        'remarks' => $requestData['remarks'],
        'resend_deadline' => $process->resend_deadline == '0000-00-00 00:00:00' ? '' : date('d-M-Y', strtotime($process->resend_deadline)),
    ];

    if ($status_id == 5) {
        CommonFunction::sendEmailSMS('APP_SHORTFALL', $appInfo, $applicantEmailPhone);
    } elseif ($status_id == 6) {
        CommonFunction::sendEmailSMS('APP_REJECT', $appInfo, $applicantEmailPhone);
    } elseif ($status_id == 19) {
        $meetingId = $requestData['board_meeting_id'];
        $boardMeeting = BoardMeting::find($meetingId);
        $appInfo['meting_number'] = $boardMeeting->meting_number;
        $appInfo['meeting_date'] = date('d-m-Y', strtotime($boardMeeting->meting_date));
        $appInfo['meeting_time'] = date('h:i:s a', strtotime($boardMeeting->meting_date));
        CommonFunction::sendEmailSMS('PROCEED_TO_MEETING', $appInfo, $applicantEmailPhone);
    }

    switch ($process->process_type_id) {
//        case 100: // Basic Information
//            if (in_array($status_id, ['25'])){
//
//                /*
//                 * Enable company eligibility for other service/ process
//                 * without eligibility, user can't access any service except Basic Information
//                 */
//                $output1 = CompanyInfo::where('id', $process->company_id)->update([
//                    'is_eligible' => 1
//                ]);
//
//                $data = [];
//                $data['approved_date'] = date('Y-m-d H:i:s');
//                $data['is_approved'] = 1;
//                $output = BasicInformation::where('id',$process->ref_id)->update($data);
//
//                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);
//
//                if($output1 && $output && $output3 && count($applicantEmailPhone) > 0){
//                    CommonFunction::sendEmailSMS('APP_APPROVE_WITHOUT_LETTER',$appInfo, $applicantEmailPhone);
//                    return true;
//                }
//            }
//
//            return true;
//            break;
        case 1:
            // Visa Recommendation New
            if (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = VisaRecommendation::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);

                if ($output and $output3 and $certificateGenerate) {  //return true

                    $appInfo['attachment_certificate_name'] = 'vr_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
                    $applicationData = VisaRecommendation::leftJoin('dept_application_type', 'dept_application_type.id', '=', 'vr_apps.app_type_id')
                        ->leftJoin('country_info', 'country_info.id', '=', 'vr_apps.emp_nationality_id')
                        ->leftJoin('high_comissions', 'high_comissions.id', '=', 'vr_apps.high_commision_id')
                        ->leftJoin('airports', 'airports.id', '=', 'vr_apps.airport_id')
                        ->where('vr_apps.id', $process->ref_id)
                        ->first([
                            'vr_apps.id',
                            'vr_apps.app_type_id',
                            'vr_apps.high_commision_id as high_commission_id',
                            'vr_apps.airport_id',
                            'vr_apps.emp_name as name',
                            'vr_apps.emp_passport_no as passport_number',
                            'vr_apps.emp_designation as designation',
                            'country_info.nationality',
                            'dept_application_type.name as visa_type',
                            'high_comissions.name as high_commission_name',
                            'high_comissions.address as high_commission_address',
                            'airports.name as airport_name',
                            'airports.city_name as airport_city',
                            'airports.country_name as airport_country'
                        ]);
                    $appInfo['name'] = $applicationData->name;
                    $appInfo['nationality'] = $applicationData->nationality;
                    $appInfo['passport_number'] = $applicationData->passport_number;
                    $appInfo['designation'] = $applicationData->designation;
                    $appInfo['visa_type'] = $applicationData->visa_type;
                    $appInfo['airport_name'] = $applicationData->airport_name;
                    $appInfo['airport_address'] = $applicationData->airport_city . ', ' . $applicationData->airport_country;
                    $appInfo['high_commission_name'] = $applicationData->high_commission_name;
                    $appInfo['high_commission_address'] = $applicationData->high_commission_address;

                    if ($applicationData->app_type_id == 5) { //Visa on arrival
                        $airportEmailPhone = Airports::where('id', $applicationData->airport_id)
                            ->get([
                                'email as user_email',
                                'phone as user_phone'
                            ]);
                        if (count($airportEmailPhone) > 0)
                            CommonFunction::sendEmailSMS('IMMIGRATION', $appInfo, $airportEmailPhone);
                    } else {
                        $embassyEmailPhone = HighComissions::where('id', $applicationData->high_commission_id)
                            ->get([
                                'email as user_email',
                                'phone as user_phone'
                            ]);
                        if (count($embassyEmailPhone) > 0)
                            CommonFunction::sendEmailSMS('EMBASSY_HIGH_COMMISSION', $appInfo, $embassyEmailPhone);
                    }


                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('VRN_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                //store VR common pool information
                VRCommonPoolManager::VRDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 2: // Work Permit New, 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting, 32 = Condition Satisfied

            if (in_array($status_id, ['8', '9', '15', '19'])) {
                if ($status_id != 8) {
                    if (empty($requestData['approved_duration_start_date']) || empty($requestData['approved_duration_end_date']) || empty($requestData['approved_desired_duration']) || empty($requestData['approved_duration_amount'])) {
                        Session::flash('error', 'Application duration not fill up.[PPC-1201]');
                        return false;
                    }
                }

                //govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $appInfo['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $approved_desired_duration = (string)$durationData['string'];
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation
                $data = [];
                $data['approved_duration_start_date'] = $appInfo['approved_duration_start_date'];
                $data['approved_duration_end_date'] = $appInfo['approved_duration_end_date'];
                $data['approved_desired_duration'] = $approved_desired_duration; //$requestData['approved_desired_duration'];
                $data['approved_duration_amount'] = $appInfo['govt_fees']; //$requestData['approved_duration_amount'];
                $data['basic_salary'] = (!empty($requestData['basic_salary']) ? $requestData['basic_salary'] : '');

//                    $duration_check = CommonFunction::durationCalculate($data['approved_duration_start_date'], $data['approved_duration_end_date'], $data['approved_desired_duration']);
//                    if($duration_check == 'false'){
//                        Session::flash('error', 'Application duration not correct.[WPN-1203]');
//                        return false;
//                    }


                $output = WorkPermitNew::where('id', $process->ref_id)->update($data);

                if ($output && in_array($status_id, ['15'])) {
                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
                }
            } elseif (in_array($status_id, ['17'])) { // 17 = conditional approved ...
                CommonFunction::sendEmailSMS('APP_CONDITIONAL_APPROVED', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['32'])) { // 32 = Condition Satisfied

                $get_duration_data = WorkPermitNew::where('id', $process->ref_id)
                    ->first(['approved_duration_start_date', 'approved_duration_end_date']);

                //  govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = $get_duration_data->approved_duration_start_date;
                $appInfo['approved_duration_end_date'] = $get_duration_data->approved_duration_end_date;
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                CommonFunction::sendEmailSMS('APP_CONDITION_SATISFIED_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = WorkPermitNew::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);

                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'wp_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = WorkPermitNew::leftJoin('country_info', 'country_info.id', '=', 'wp_apps.emp_nationality_id')
                            ->where('wp_apps.id', $process->ref_id)
                            ->first([
                                'country_info.nationality',
                                'wp_apps.*'
                            ]);

                        $appInfo['name'] = $applicationData->emp_name;
                        $appInfo['designation'] = $applicationData->emp_designation;
                        $appInfo['nationality'] = $applicationData->nationality;
                        $appInfo['passport_number'] = $applicationData->emp_passport_no;
                        CommonFunction::sendEmailSMS('WP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }

                }

                WPCommonPoolManager::wpnDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 3: // Work Permit Extension, 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting, 32 = Condition Satisfied
            if (in_array($status_id, ['8', '9', '15', '19'])) {
                if ($status_id != 8) {
                    if (empty($requestData['approved_duration_start_date']) || empty($requestData['approved_duration_end_date']) || empty($requestData['approved_desired_duration']) || empty($requestData['approved_duration_amount'])) {
                        \Session::flash('error', 'Application duration not fill up.[PPC-1216]');
                        return false;
                    }
                }

                //  govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $appInfo['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $approved_desired_duration = (string)$durationData['string'];
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                $data = [];
                $data['approved_duration_start_date'] = $appInfo['approved_duration_start_date'];
                $data['approved_duration_end_date'] = $appInfo['approved_duration_end_date'];
                $data['approved_desired_duration'] = $approved_desired_duration;
                $data['approved_duration_amount'] = $appInfo['govt_fees'];
                $data['basic_salary'] = (!empty($requestData['basic_salary']) ? $requestData['basic_salary'] : '');

                $output = WorkPermitExtension::where('id', $process->ref_id)->update($data);

                if ($output && in_array($status_id, ['15'])) {
                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
                }
            } elseif (in_array($status_id, ['17'])) { // 17 = conditional approved
                CommonFunction::sendEmailSMS('APP_CONDITIONAL_APPROVED', $appInfo, $applicantEmailPhone);

            } elseif (in_array($status_id, ['32'])) { // 32 = Condition Satisfied
                $get_duration_data = WorkPermitExtension::where('id', $process->ref_id)
                    ->first(['approved_duration_start_date', 'approved_duration_end_date', 'approved_desired_duration']);

                // govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = $get_duration_data->approved_duration_start_date;
                $appInfo['approved_duration_end_date'] = $get_duration_data->approved_duration_end_date;
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                CommonFunction::sendEmailSMS('APP_CONDITION_SATISFIED_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = WorkPermitExtension::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);
                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);

                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'wpe_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = WorkPermitExtension::leftJoin('country_info', 'country_info.id', '=', 'wpe_apps.emp_nationality_id')
                            ->where('wpe_apps.id', $process->ref_id)
                            ->first([
                                'country_info.nationality',
                                'wpe_apps.*'
                            ]);

                        $appInfo['name'] = $applicationData->emp_name;
                        $appInfo['designation'] = $applicationData->emp_designation;
                        $appInfo['nationality'] = $applicationData->nationality;
                        $appInfo['passport_number'] = $applicationData->emp_passport_no;
                        CommonFunction::sendEmailSMS('WP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                WPCommonPoolManager::wpeDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 4: // Work Permit Amendment 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting
            if (in_array($status_id, ['8', '9', '15', '19'])) {
                $getWPAinfo = WorkPermitAmendment::where('id', $process->ref_id)
                    ->first([
                        'n_duration_start_date',
                        'n_duration_end_date',
                        'n_desired_duration',
                        'approved_effective_date'
                    ]);

                $data = [];
                if (($getWPAinfo->n_duration_start_date != '' and $getWPAinfo->n_duration_start_date != '0000-00-00') ||
                    ($getWPAinfo->n_duration_end_date != '' and $getWPAinfo->n_duration_end_date != '0000-00-00') ||
                    ($getWPAinfo->n_desired_duration != '' and $getWPAinfo->n_desired_duration != null)) {
                    if ($status_id != 8) {
                        if (empty($requestData['approved_duration_start_date']) || empty($requestData['approved_duration_end_date']) || empty($requestData['approved_desired_duration'])) {
                            \Session::flash('error', 'Application duration not fill up.[PPC-1217]');
                            return false;
                        }
                    }

                    $data['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                    $data['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                    $data['approved_desired_duration'] = $requestData['approved_desired_duration'];
                    $data['approved_duration_amount'] = $requestData['approved_duration_amount'];
                    $data['basic_salary'] = (!empty($requestData['basic_salary']) ? $requestData['basic_salary'] : '');
                }

                //effective approved date
                if ($getWPAinfo->approved_effective_date != '0000-00-00' && $getWPAinfo->approved_effective_date != '') {
                    $data['approved_effective_date'] = (!empty($requestData['approved_effective_date']) ? date('Y-m-d', strtotime($requestData['approved_effective_date'])) : '');
                }

                $output = WorkPermitAmendment::where('id', $process->ref_id)->update($data);
                if (!$output) {
                    \Session::flash('error', 'Application duration update error.[PPC-1215]');
                    return false;
                }

                if (in_array($status_id, ['15'])) {
                    $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
                }

            } elseif (in_array($status_id, ['17'])) { // 17 = conditional approved
                CommonFunction::sendEmailSMS('APP_CONDITIONAL_APPROVED', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = WorkPermitAmendment::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'wpa_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);
                    //Email is not sending to stakeholder at issue letter for amendment as per discussion

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = WorkPermitAmendment::leftJoin('country_info', 'country_info.id', '=', 'wpa_apps.emp_nationality_id')
                            ->where('wpa_apps.id', $process->ref_id)
                            ->first([
                                'country_info.nationality',
                                'wpa_apps.*'
                            ]);

                        $appInfo['name'] = $applicationData->emp_name;
                        $appInfo['designation'] = $applicationData->emp_designation;
                        $appInfo['nationality'] = $applicationData->nationality;
                        $appInfo['passport_number'] = $applicationData->emp_passport_no;
                        CommonFunction::sendEmailSMS('WP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                WPCommonPoolManager::wpaDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 5: // Work Permit Cancellation, 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting
            if (in_array($status_id, ['8', '9', '15', '19'])) { // Approved form Meeting Chairperson or Director
                if ($status_id != 8) {
                    if (empty($requestData['approved_effect_date'])) {
                        \Session::flash('error', 'Application duration not fill up.[PPC-1295]');
                        return false;
                    }
                }
                $data = [];
                $data['approved_effect_date'] = (!empty($requestData['approved_effect_date']) ? date('Y-m-d', strtotime($requestData['approved_effect_date'])) : '');
                $output = WorkPermitCancellation::where('id', $process->ref_id)->update($data);
                if (!$output) {
                    \Session::flash('error', 'Application duration update error!.[PPC-1296]');
                    return false;
                }
                if (in_array($status_id, ['15'])) {
                    CommonFunction::sendEmailSMS('APP_APPROVE_WITHOUT_LETTER', $appInfo, $applicantEmailPhone);
                }
            } elseif (in_array($status_id, ['17'])) { // 17 = conditional approved
                CommonFunction::sendEmailSMS('APP_CONDITIONAL_APPROVED', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = WorkPermitCancellation::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'wpc_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = WorkPermitCancellation::leftJoin('country_info', 'country_info.id', '=', 'wpc_apps.applicant_nationality')
                            ->where('wpc_apps.id', $process->ref_id)
                            ->first([
                                'country_info.nationality',
                                'wpc_apps.*'
                            ]);

                        $appInfo['name'] = $applicationData->applicant_name;
                        $appInfo['designation'] = $applicationData->applicant_position;
                        $appInfo['nationality'] = $applicationData->nationality;
                        $appInfo['passport_number'] = $applicationData->applicant_pass_no;
                        CommonFunction::sendEmailSMS('WP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                WPCommonPoolManager::wpcDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 6: // Office Permission New 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting, 32 = Condition Satisfied
            // Proceed to meeting from Desk(3)
            if (in_array($status_id, ['8', '9', '15', '19'])) {
                if ($status_id != 8) {
                    if (empty($requestData['approved_duration_start_date']) || empty($requestData['approved_duration_end_date']) || empty($requestData['approved_desired_duration']) || empty($requestData['approved_duration_amount'])) {
                        \Session::flash('error', 'Application duration not fill up.[PPC-1212]');
                        return false;
                    }
                }

                //  govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $appInfo['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $approved_desired_duration = (string)$durationData['string'];
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                $data = [];
                $data['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $data['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $data['approved_desired_duration'] = $approved_desired_duration;
                $data['approved_duration_amount'] = $appInfo['govt_fees'];

                $output = OfficePermissionNew::where('id', $process->ref_id)->update($data);
                if (!$output) {
                    \Session::flash('error', 'Application duration update error!.[PPC-1213]');
                    return false;
                }

                // Approved from Desk
                if (in_array($status_id, ['15']) && $output) {
                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
                }

            } elseif (in_array($status_id, ['32'])) { // 32 = Condition Satisfied
                $get_duration_data = OfficePermissionNew::where('id', $process->ref_id)
                    ->first(['approved_duration_start_date', 'approved_duration_end_date']);

                // govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = $get_duration_data->approved_duration_start_date;
                $appInfo['approved_duration_end_date'] = $get_duration_data->approved_duration_end_date;
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                CommonFunction::sendEmailSMS('APP_CONDITION_SATISFIED_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } // Issued office permission from Desk(1)
            elseif ($status_id == 25) {

                $opn_company_info = OfficePermissionNew::where('id', $process->ref_id)->first(['local_company_name', 'local_company_name_bn']);

                // check company is exist
                $checkExitingCompany = CommonFunction::findCompanyNameWithoutWorkingID($opn_company_info->local_company_name, $process->company_id);
                if ($checkExitingCompany == false) {
                    \Session::flash('error', 'Company name: "' . $opn_company_info->local_company_name . '" is already exist!');
                    return false;
                }

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = OfficePermissionNew::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                // Update company name in company information and basic information table
                $basic_app_id = ProcessList::leftjoin('ea_apps', 'ea_apps.id', '=', 'process_list.ref_id')
                    ->where('process_list.process_type_id', 100)
                    ->where('process_list.status_id', 25)
                    ->where('process_list.company_id', $process->company_id)
                    ->first(['process_list.ref_id']);

                $opn_company_info_data = [];
                $opn_company_info_data['company_name'] = $opn_company_info->local_company_name;
                $opn_company_info_data['company_name_bn'] = $opn_company_info->local_company_name_bn;

                CompanyInfo::where('id', $process->company_id)->update($opn_company_info_data);
                BasicInformation::where('id', $basic_app_id->ref_id)->update($opn_company_info_data);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'opn_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = OfficePermissionNew::find($process->ref_id);
                        $appInfo['organization_name'] = $applicationData->company_name;
                        CommonFunction::sendEmailSMS('OP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                $isDataStored = OPCommonPoolManager::OPNDataStore($process->tracking_no, $process->ref_id);
                if ($isDataStored === false) {
                    return false;
                }
            }
            return true;
            break;

        case 7: // Office Permission Extension, 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting, 32 = Condition Satisfied
            if (in_array($status_id, ['8', '9', '19'])) {
                if ($status_id != 8) {
                    if (empty($requestData['approved_duration_start_date']) || empty($requestData['approved_duration_end_date']) || empty($requestData['approved_desired_duration']) || empty($requestData['approved_duration_amount'])) {
                        \Session::flash('error', 'Application duration not fill up.[PPC-1212]');
                        return false;
                    }
                }

                //  govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $appInfo['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $approved_desired_duration = (string)$durationData['string'];
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                $data = [];
                $data['approved_is_remittance_allowed'] = (!empty($requestData['approved_is_remittance_allowed']) ? $requestData['approved_is_remittance_allowed'] : 'no');
                $data['approved_duration_start_date'] = (!empty($requestData['approved_duration_start_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_start_date'])) : '');
                $data['approved_duration_end_date'] = (!empty($requestData['approved_duration_end_date']) ? date('Y-m-d', strtotime($requestData['approved_duration_end_date'])) : '');
                $data['approved_desired_duration'] = $approved_desired_duration;
                $data['approved_duration_amount'] = $appInfo['govt_fees'];

                $output = OfficePermissionExtension::where('id', $process->ref_id)->update($data);
                if (!$output) {
                    \Session::flash('error', 'Application duration update error!.[PPC-1213]');
                    return false;
                }

                // Approved from Desk
//                if (in_array($status_id, ['15']) && $output) {
//                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
//                }

            } elseif (in_array($status_id, ['32'])) { // 32 = Condition Satisfied
                $get_duration_data = OfficePermissionExtension::where('id', $process->ref_id)
                    ->first(['approved_duration_start_date', 'approved_duration_end_date']);

                // govt fees calculation and send mail.
                $appInfo['approved_duration_start_date'] = $get_duration_data->approved_duration_start_date;
                $appInfo['approved_duration_end_date'] = $get_duration_data->approved_duration_end_date;
                $durationData = commonFunction::getDesiredDurationDiffDate($appInfo);
                $appInfo['approve_duration_year'] = (int)$durationData['approve_duration_year'];
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                // end of gov fees calculation

                CommonFunction::sendEmailSMS('APP_CONDITION_SATISFIED_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } // Issued office permission from Desk(1)
            elseif ($status_id == 25) {

                $ope_company_info = OfficePermissionExtension::where('id', $process->ref_id)->first(['local_company_name', 'local_company_name_bn']);

                // check company is exist
                $checkExitingCompany = CommonFunction::findCompanyNameWithoutWorkingID($ope_company_info->local_company_name, $process->company_id);
                if ($checkExitingCompany == false) {
                    \Session::flash('error', 'Company name: "' . $ope_company_info->local_company_name . '" is already exist!');
                    return false;
                }

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = OfficePermissionExtension::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                // Update company name in company information and basic information table
                $basic_app_id = ProcessList::leftjoin('ea_apps', 'ea_apps.id', '=', 'process_list.ref_id')
                    ->where('process_list.process_type_id', 100)
                    ->where('process_list.status_id', 25)
                    ->where('process_list.company_id', $process->company_id)
                    ->first(['process_list.ref_id']);

                $ope_company_info_data = [];
                $ope_company_info_data['company_name'] = $ope_company_info->local_company_name;
                $ope_company_info_data['company_name_bn'] = $ope_company_info->local_company_name_bn;

                CompanyInfo::where('id', $process->company_id)->update($ope_company_info_data);
                BasicInformation::where('id', $basic_app_id->ref_id)->update($ope_company_info_data);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'ope_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = OfficePermissionExtension::find($process->ref_id);
                        $appInfo['organization_name'] = $applicationData->company_name;
                        CommonFunction::sendEmailSMS('OP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                $isDataStored = OPCommonPoolManager::OPEDataStore($process->tracking_no, $process->ref_id);
                if ($isDataStored === false) {
                    return false;
                }
            }
            return true;
            break;

        case 8: // Office Permission Amendment (8)

            // This will be uncommented if second time payment is required
            if (in_array($status_id, ['8', '9', '15', '19'])) {
                // update approved effective date
                $data = [];
                $data['approved_effective_date'] = (!empty($requestData['approved_effective_date']) ? date('Y-m-d', strtotime($requestData['approved_effective_date'])) : '');
                OfficePermissionAmendment::where('id', $process->ref_id)->update($data);

                if (in_array($status_id, ['15'])) {
                    $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                    CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
                }

            } elseif ($status_id == 25) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = OfficePermissionAmendment::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'opa_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);
                    //Email is not sending to stakeholder at issue letter for amendment as per discussion

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = OfficePermissionAmendment::find($process->ref_id);
                        $appInfo['organization_name'] = $applicationData->local_company_name;
                        CommonFunction::sendEmailSMS('OP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }
                $isDataStored = OPCommonPoolManager::OPADataStore($process->tracking_no, $process->ref_id);
                if ($isDataStored === false) {
                    return false;
                }
            }
            return true;
            break;

        case 9: // Office Permission Cancellation, 8 = Observation, 9 = Verified, 15 = Approved, 19 = Proceed to Meeting
            if (in_array($status_id, ['8', '9', '15', '19'])) { // Approved from Meeting Chairperson or Director
                if ($status_id != 8) {
                    if (empty($requestData['approved_effect_date'])) {
                        \Session::flash('error', 'Application duration not fill up.[PPC-1214]');
                        return false;
                    }
                }
                $data = [];
                $data['approved_effect_date'] = (!empty($requestData['approved_effect_date']) ? date('Y-m-d', strtotime($requestData['approved_effect_date'])) : '');
                $output = OfficePermissionCancellation::where('id', $process->ref_id)->update($data);
                if (!$output) {
                    \Session::flash('error', 'Application duration update error!.[PPC-1213]');
                    return false;
                }
                if (in_array($status_id, ['15'])) {
                    CommonFunction::sendEmailSMS('APP_APPROVE_WITHOUT_LETTER', $appInfo, $applicantEmailPhone);
                }
            } elseif ($status_id == 25) { // Issue Office Cancellation from Assistant Director
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = OfficePermissionCancellation::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'opc_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        $applicationData = OfficePermissionCancellation::find($process->ref_id);
                        $appInfo['organization_name'] = $applicationData->company_name;
                        CommonFunction::sendEmailSMS('OP_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                $isDataStored = OPCommonPoolManager::OPCDataStore($process->tracking_no, $process->ref_id);
                if ($isDataStored === false) {
                    return false;
                }
            }

//            elseif ($status_id == 5) {
//                if (!empty($requestData['opc_shortfall_review_section'])) {
//                    $data = [];
//                    $review_section_array = [
//                        'basic_instruction_review',
//                        'office_type_review',
//                        'company_info_review',
//                        'capital_of_company_review',
//                        'local_address_review',
//                        'activities_in_bd_review',
//                        'period_of_permission_review',
//                        'organizational_set_up_review',
//                        'expenses_review',
//                        'attachment_review',
//                        'declaration_review'
//                    ];
//                    foreach ($review_section_array as $key => $value) {
//                        if (array_search($value, $requestData['opc_shortfall_review_section']) !== false) {
//                            $data[$value] = 1;
//                        } else {
//                            $data[$value] = 0;
//                        }
//                    }
//
//                    OfficePermissionCancellation::where('id', $process->ref_id)->update($data);
//                }
//            }

            return true;
            break;

        case 10: // Visa Recommendation Amendment (10)
            if (in_array($status_id, ['15'])) {
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif ($status_id == 25) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = VisaRecommendationAmendment::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);
                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'vra_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $applicationData = VisaRecommendationAmendment::leftJoin('dept_application_type', 'dept_application_type.id', '=', 'vra_apps.app_type_id')
                        ->leftJoin('country_info', 'country_info.id', '=', 'vra_apps.emp_nationality_id')
                        ->leftJoin('high_comissions', 'high_comissions.id', '=', 'vra_apps.n_high_commision_id')
                        ->where('vra_apps.id', $process->ref_id)
                        ->first([
                            'vra_apps.id',
                            'vra_apps.app_type_id',
                            'vra_apps.high_commision_id as high_commission_id',
                            'vra_apps.n_high_commision_id as n_high_commission_id',
                            'high_comissions.name as high_commission_name',
                            'high_comissions.address as high_commission_address',
                            'vra_apps.n_mission_country_id',
                            'vra_apps.airport_id',
                            'vra_apps.n_airport_id',
                            'vra_apps.emp_name as name',
                            'vra_apps.emp_passport_no as passport_number',
                            'vra_apps.emp_designation as designation',
                            'country_info.nationality',
                            'dept_application_type.name as visa_type',
                        ]);

                    $appInfo['name'] = $applicationData->name;
                    $appInfo['nationality'] = $applicationData->nationality;
                    $appInfo['passport_number'] = $applicationData->passport_number;
                    $appInfo['designation'] = $applicationData->designation;
                    $appInfo['visa_type'] = $applicationData->visa_type;
                    $appInfo['high_commission_name'] = $applicationData->high_commission_name;
                    $appInfo['high_commission_address'] = $applicationData->high_commission_address;

                    // If embassy/ high commission is changed then send email both embassy/ high commission
                    if ($applicationData->app_type_id != 5 && !empty($applicationData->n_mission_country_id) && !empty($applicationData->n_high_commission_id)) {
                        $embassyEmailPhone = HighComissions::whereIn('id', [$applicationData->high_commission_id, $applicationData->n_high_commission_id])
                            ->get([
                                'email as user_email',
                                'phone as user_phone'
                            ]);
                        if (count($embassyEmailPhone) > 0)
                            CommonFunction::sendEmailSMS('EMBASSY_HIGH_COMMISSION', $appInfo, $embassyEmailPhone);
                    }

//                    if ($applicationData->app_type_id == 5) { // Visa on arrival
//                        $airportEmailPhone = Airports::whereIn('id', [$applicationData->airport_id,$applicationData->n_airport_id])
//                            ->get([
//                                'email as user_email',
//                                'phone as user_phone'
//                            ]);
//                        if (count($airportEmailPhone) > 0)
//                            CommonFunction::sendEmailSMS('IMMIGRATION', $appInfo, $airportEmailPhone);
//                    }

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('VRA_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                //store VR common pool information
                VRCommonPoolManager::VRADataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 11: // Remittance Approval new (11)
            if ($status_id == '15') {
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['32'])) { // 32 = Condition Satisfied
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                CommonFunction::sendEmailSMS('APP_CONDITION_SATISFIED_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif ($status_id == '18') { // 18 = Payment Confirm
                // Store approver information
                storeSignatureQRCode($process->process_type_id, $process->ref_id, 0, $approver_desk_id, 'first');
                // qr code
            } elseif (in_array($status_id, ['25'])) {
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');

                $output = Remittance::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id, $process->department_id);

                if ($output and $output3 and $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'ra_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_ISSUED_LETTER', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('REMITTANCE_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }
            }
            return true;
            break;

        case 12: // BIDA Registration Amendment
            if ($status_id == '15') {
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = BidaRegistrationAmendment::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);
                // Generate Registration number
                $bRegistration = new BidaRegistrationAmendmentController();
                $bRegistration->RegNoGenerate($process->ref_id, $process->approval_center_id);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);
                $listOfDirectorAndMechineryGenerate = UtilFunction::getBRAListOfDirectorsAndMachinery($process->ref_id, $process->process_type_id, 'F');

                if ($output && $output3 && !empty($listOfDirectorAndMechineryGenerate) && $certificateGenerate) {  //return true

                    $appInfo['attachment'] = $_SERVER['DOCUMENT_ROOT'] . '/' . $listOfDirectorAndMechineryGenerate;
                    $appInfo['attachment_certificate_name'] = 'bra_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('BR_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                //store BR common pool information
                BRCommonPoolManager::BRADataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 13: // IRC 1st adhoc

//            if ($status_id == '15') {
//                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
//                CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
//            }


            if (in_array($status_id, ['40'])) {

                $io_submission_deadline = (!empty($requestData['io_submission_deadline']) ? date('Y-m-d', strtotime($requestData['io_submission_deadline'])) : '');
                $output = IrcRecommendationNew::where('id', $process->ref_id)
                    ->update([
                        'io_submission_deadline' => $io_submission_deadline
                    ]);
                if (!$output) {
                    \Session::flash('error', 'Inspection submission deadline date error!.[PPC-1221]');
                    return false;
                }

                $applicationData = IrcRecommendationNew::leftJoin('irc_types', 'irc_apps.app_type_id', '=', 'irc_types.id')
                    ->Where('irc_apps.id', $process->ref_id)
                    ->first(['irc_apps.company_name', 'irc_types.type']);

                $desk_user_info = Users::where('id', $process->user_id)
                    ->get([
                        'user_first_name', 'user_middle_name', 'user_last_name', 'designation', 'user_phone', 'user_email'
                    ]);

                $appInfo['irc_type'] = $applicationData->type;
                $appInfo['organization_name'] = $applicationData->company_name;
                $appInfo['ins_officer_name'] = $desk_user_info[0]->user_first_name . ' ' . $desk_user_info[0]->user_middle_name . ' ' . $desk_user_info[0]->user_last_name;
                $appInfo['ins_officer_designation'] = $desk_user_info[0]->designation;
                $appInfo['ins_officer_phone_no'] = $desk_user_info[0]->user_phone;
                $appInfo['ins_officer_email'] = $desk_user_info[0]->user_email;
                $appInfo['io_submission_deadline'] = $io_submission_deadline;

                // send mail
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_APPLICANT_CONTENT', $appInfo, $applicantEmailPhone);
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_DESK_CONTENT', $appInfo, $desk_user_info);
            }

            // This code will be removed after process button disabled code successful run
//            elseif ($status_id == '41' && $process->user_id == 0) { // Field visit
//                ProcessList::where('id', $process_list_id)->update(['user_id' => Auth::user()->id]);
//            }

            elseif (in_array($status_id, ['42'])) {
                //store inspection information here
                inspectionStore($requestData);
            }
            elseif (in_array($status_id, ['8', '9'])) {
                $deputy_director_info_update = IrcInspection::where('app_id', $process->ref_id)
                    ->orderBy('id', 'desc')
                    ->first();
                $deputy_director_info_update->dd_name = CommonFunction::getUserFullName();
                $deputy_director_info_update->dd_designation = Auth::user()->designation;
                $deputy_director_info_update->dd_mobile_no = Auth::user()->user_phone;
                $deputy_director_info_update->dd_email = Auth::user()->user_email;
                $deputy_director_info_update->dd_signature = Auth::user()->signature;
                $deputy_director_info_update->save();
            }
            elseif (in_array($status_id, ['25'])) {

                if (empty($requestData['ins_approved_id'])) {
                    \Session::flash('error', 'Inspection report not approved. [PPC-1232]');
                    return false;
                }

                // Update approved inspection data
               $decode_ins_approved_id = Encryption::decodeId($requestData['ins_approved_id']);
               $inspection = IrcInspection::where(['id' => $decode_ins_approved_id, 'app_id' => $process->ref_id])->first();
               $inspection->ins_approved_status = 1;
               $inspection->save();
                // $inspection = IrcInspection::where(['id' => $decode_ins_approved_id, 'app_id' => $process->ref_id])->update(['ins_approved_status' => 1]);

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = IrcRecommendationNew::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);

                if ($output && $output3 && $certificateGenerate) {  //return true
                    //$appInfo['attachment_certificate_name'] = 'irc_apps.certificate_link';
                    //CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);

                    $inspection_amount = 0;           
                    if ($inspection->irc_purpose_id == 1) {
                        $inspection_amount = $inspection->apc_half_yearly_import_total;
                    } elseif ($inspection->irc_purpose_id == 2) {
                        $inspection_amount = $inspection->em_lc_total_five_percent;
                    } elseif ($inspection->irc_purpose_id == 3) {
                        $inspection_amount = ($inspection->apc_half_yearly_import_total + $inspection->em_lc_total_five_percent);
                    }

                    $appInfo['inspection_amount'] = $inspection_amount;
                    CommonFunction::sendEmailSMS('APP_APPROVE_EXCEPT_IRC_APPROVAL_COPY', $appInfo, $applicantEmailPhone);
                }
                IRCCommonPoolManager::ircFirstAdhocDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 14: // IRC 2nd adhoc
            if (in_array($status_id, ['40'])) {

                $io_submission_deadline = (!empty($requestData['io_submission_deadline']) ? date('Y-m-d', strtotime($requestData['io_submission_deadline'])) : '');
                $output = IrcRecommendationSecondAdhoc::where('id', $process->ref_id)
                    ->update([
                        'io_submission_deadline' => $io_submission_deadline
                    ]);
                if (!$output) {
                    \Session::flash('error', 'Inspection submission deadline date error!.[PPC-1221]');
                    return false;
                }

                $applicationData = IrcRecommendationSecondAdhoc::leftJoin('irc_types', 'irc_2nd_apps.app_type_id', '=', 'irc_types.id')
                    ->Where('irc_2nd_apps.id', $process->ref_id)
                    ->first(['irc_2nd_apps.company_name', 'irc_types.type']);

                $desk_user_info = Users::where('id', $process->user_id)
                    ->get([
                        'user_first_name', 'user_middle_name', 'user_last_name', 'designation', 'user_phone', 'user_email'
                    ]);

                $appInfo['irc_type'] = $applicationData->type;
                $appInfo['organization_name'] = $applicationData->company_name;
                $appInfo['ins_officer_name'] = $desk_user_info[0]->user_first_name . ' ' . $desk_user_info[0]->user_middle_name . ' ' . $desk_user_info[0]->user_last_name;
                $appInfo['ins_officer_designation'] = $desk_user_info[0]->designation;
                $appInfo['ins_officer_phone_no'] = $desk_user_info[0]->user_phone;
                $appInfo['ins_officer_email'] = $desk_user_info[0]->user_email;
                $appInfo['io_submission_deadline'] = $io_submission_deadline;

                // send mail
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_APPLICANT_CONTENT', $appInfo, $applicantEmailPhone);
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_DESK_CONTENT', $appInfo, $desk_user_info);
            } elseif (in_array($status_id, ['42'])) {
                //store inspection information here
                inspectionStore($requestData);
            } elseif (in_array($status_id, ['8', '9'])) {
                $deputy_director_info_update = SecondIrcInspection::where('app_id', $process->ref_id)
                    ->orderBy('id', 'desc')
                    ->first();

                if (!empty($deputy_director_info_update)) {
                    $deputy_director_info_update->dd_name = CommonFunction::getUserFullName();
                    $deputy_director_info_update->dd_designation = Auth::user()->designation;
                    $deputy_director_info_update->dd_mobile_no = Auth::user()->user_phone;
                    $deputy_director_info_update->dd_email = Auth::user()->user_email;
                    $deputy_director_info_update->dd_signature = Auth::user()->signature;
                    $deputy_director_info_update->save();
                }

            } elseif (in_array($status_id, ['25'])) {
                if (!empty($requestData['ins_approved_id'])) {
                    $decode_ins_approved_id = Encryption::decodeId($requestData['ins_approved_id']);

                    $getIRCSecondInspectionData = SecondIrcInspection::where(['id' => $decode_ins_approved_id, 'app_id' => $process->ref_id])->first();

                    IrcRecommendationSecondAdhoc::where('id', $process->ref_id)->update([
                        'second_em_lc_total_taka_mil' => $getIRCSecondInspectionData->em_lc_total_taka_mil,
                        'second_em_lc_total_percent' => $getIRCSecondInspectionData->em_lc_total_percent,
                        'second_em_lc_total_five_percent' => $getIRCSecondInspectionData->em_lc_total_five_percent,
                        'second_em_lc_total_five_percent_in_word' => $getIRCSecondInspectionData->em_lc_total_five_percent_in_word
                    ]);

                    $getIRCSecondInspectionData->ins_approved_status = 1;
                    $getIRCSecondInspectionData->save();
                }

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = IrcRecommendationSecondAdhoc::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);

                if ($output && $output3 && $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'irc_2nd_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
                }
                IRCCommonPoolManager::ircSecondAdhocDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 15: // IRC 3rd adhoc

            if (in_array($status_id, ['40'])) {

                $io_submission_deadline = (!empty($requestData['io_submission_deadline']) ? date('Y-m-d', strtotime($requestData['io_submission_deadline'])) : '');
                $output = IrcRecommendationThirdAdhoc::where('id', $process->ref_id)
                    ->update([
                        'io_submission_deadline' => $io_submission_deadline
                    ]);
                if (!$output) {
                    \Session::flash('error', 'Inspection submission deadline date error!.[PPC-1221]');
                    return false;
                }

                $applicationData = IrcRecommendationThirdAdhoc::leftJoin('irc_types', 'irc_3rd_apps.app_type_id', '=', 'irc_types.id')
                    ->Where('irc_3rd_apps.id', $process->ref_id)
                    ->first(['irc_3rd_apps.company_name', 'irc_types.type']);

                $desk_user_info = Users::where('id', $process->user_id)
                    ->get([
                        'user_first_name', 'user_middle_name', 'user_last_name', 'designation', 'user_phone', 'user_email'
                    ]);

                $appInfo['irc_type'] = $applicationData->type;
                $appInfo['organization_name'] = $applicationData->company_name;
                $appInfo['ins_officer_name'] = $desk_user_info[0]->user_first_name . ' ' . $desk_user_info[0]->user_middle_name . ' ' . $desk_user_info[0]->user_last_name;
                $appInfo['ins_officer_designation'] = $desk_user_info[0]->designation;
                $appInfo['ins_officer_phone_no'] = $desk_user_info[0]->user_phone;
                $appInfo['ins_officer_email'] = $desk_user_info[0]->user_email;
                $appInfo['io_submission_deadline'] = $io_submission_deadline;

                // send mail
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_APPLICANT_CONTENT', $appInfo, $applicantEmailPhone);
                CommonFunction::sendEmailSMS('IRC_IO_ASSIGN_DESK_CONTENT', $appInfo, $desk_user_info);
            } elseif (in_array($status_id, ['42'])) {
                //store inspection information here
                inspectionStore($requestData);
            } elseif (in_array($status_id, ['8', '9'])) {
                $deputy_director_info_update = ThirdIrcInspection::where('app_id', $process->ref_id)
                    ->orderBy('id', 'desc')
                    ->first();

                if (!empty($deputy_director_info_update)) {
                    $deputy_director_info_update->dd_name = CommonFunction::getUserFullName();
                    $deputy_director_info_update->dd_designation = Auth::user()->designation;
                    $deputy_director_info_update->dd_mobile_no = Auth::user()->user_phone;
                    $deputy_director_info_update->dd_email = Auth::user()->user_email;
                    $deputy_director_info_update->dd_signature = Auth::user()->signature;
                    $deputy_director_info_update->save();
                }

            } elseif (in_array($status_id, ['25'])) {

                if (!empty($requestData['ins_approved_id'])) {
                    $decode_ins_approved_id = Encryption::decodeId($requestData['ins_approved_id']);

                    $getIRCThirdInspectionData = ThirdIrcInspection::where(['id' => $decode_ins_approved_id, 'app_id' => $process->ref_id])->first();

                    IrcRecommendationThirdAdhoc::where('id', $process->ref_id)->update([
                        'second_em_lc_total_taka_mil' => $getIRCThirdInspectionData->em_lc_total_taka_mil,
                        'second_em_lc_total_percent' => $getIRCThirdInspectionData->em_lc_total_percent,
                        'second_em_lc_total_five_percent' => $getIRCThirdInspectionData->em_lc_total_five_percent,
                        'second_em_lc_total_five_percent_in_word' => $getIRCThirdInspectionData->em_lc_total_five_percent_in_word
                    ]);

                    $getIRCThirdInspectionData->ins_approved_status = 1;
                    $getIRCThirdInspectionData->save();
                }

                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = IrcRecommendationThirdAdhoc::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);

                if ($output && $output3 && $certificateGenerate) {  //return true
                    $appInfo['attachment_certificate_name'] = 'irc_3rd_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
                }

                IRCCommonPoolManager::ircThirdAdhocDataStore($process->tracking_no, $process->ref_id);
            }
            return true;
            break;

        case 17:
            // VIP Lounge
            if ($status_id == 25) {
                // update application data
                $approved_datetime = date('Y-m-d H:i:s');
                $output = VipLounge::where('id', $process->ref_id)->update(['approved_date' => $approved_datetime]);
                $output1 = ProcessList::where('id', $process_list_id)->update(['completed_date' => $approved_datetime]);
                
                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);

                if ($output and $output1 and $certificateGenerate) {  //return true
                    
                    $applicationData = VipLounge::leftJoin('airports', 'airports.id', '=', 'vipl_apps.airport_id')
                        ->where('vipl_apps.id', $process->ref_id)
                        ->first([
                            'vipl_apps.id',
                            'vipl_apps.airport_id',
                            'vipl_apps.emp_name as name',
                            'vipl_apps.emp_designation as designation',
                            'vipl_apps.company_name as company_name',
                        ]);

                    $appInfo['name'] = $applicationData->name;
                    $appInfo['designation'] = $applicationData->designation;
                    $appInfo['company_name'] = $applicationData->company_name;
                    $appInfo['approved_date'] = $approved_datetime;
                    $appInfo['attachment_certificate_name'] = 'vipl_apps.certificate_link';

                    if ($applicationData->airport_id) {
                        $airportEmailPhone = Airports::where('id', $applicationData->airport_id)
                            ->get([
                                'email as user_email',
                                'phone as user_phone'
                            ]);
                        if (count($airportEmailPhone) > 0) {
                            CommonFunction::sendEmailSMS('VIPL_IMMIGRATION', $appInfo, $airportEmailPhone);
                        }
                    }

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);
                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('VIPL_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }

                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
                }
            }

            return true;
            break;

        case 102: // BIDA Registration
            if ($status_id == '15') {
                $appInfo['govt_fees'] = CommonFunction::getGovtFees($appInfo);
                CommonFunction::sendEmailSMS('APP_APPROVE_AND_PAYMENT', $appInfo, $applicantEmailPhone);
            } elseif (in_array($status_id, ['25'])) {
                // update application data
                $data = [];
                $data['approved_date'] = date('Y-m-d H:i:s');
                $output = BidaRegistration::where('id', $process->ref_id)->update($data);
                $output3 = ProcessList::where('id', $process_list_id)->update(['completed_date' => date('Y-m-d H:i:s')]);
                // Generate Registration number
                $bRegistration = new BidaRegistrationController();
                $bRegistration->RegNoGenerate($process->ref_id, $process->approval_center_id);

                $certificateGenerate = certificateGenerationRequest($process->ref_id, $process->process_type_id, $approver_desk_id);
                $listOfDirectorAndMechineryGenerate = UtilFunction::getListOfDirectorsAndMachinery($process->ref_id, $process->process_type_id, "F");

                if ($output && $output3 && !empty($listOfDirectorAndMechineryGenerate) && $certificateGenerate) {  //return true

                    $appInfo['attachment'] = $_SERVER['DOCUMENT_ROOT'] . '/' . $listOfDirectorAndMechineryGenerate;
                    $appInfo['attachment_certificate_name'] = 'br_apps.certificate_link';
                    CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);

                    $stakeholderEmailPhone = Stakeholder::where('process_type_id', $process->process_type_id)
                        ->where('department_id', $process->department_id)
                        ->where('status',1)
                        ->get([
                            'email as user_email',
                            'phone as user_phone'
                        ]);

                    if (count($stakeholderEmailPhone) > 0) {
                        CommonFunction::sendEmailSMS('BR_ISSUED_LETTER_STAKEHOLDER', $appInfo, $stakeholderEmailPhone);
                    }
                }

                //store BR common pool information
                BRCommonPoolManager::BRDataStore($process->tracking_no, $process->ref_id);

            } elseif ($status_id == 5) {
                if (!empty($requestData['br_shortfall_review_section'])) {
                    $data = [];
                    $review_section_array = [
                        'company_info_review',
                        'promoter_info_review',
                        'office_address_review',
                        'factory_address_review',
                        'project_status_review',
                        'production_capacity_review',
                        'commercial_operation_review',
                        'sales_info_review',
                        'manpower_review',
                        'investment_review',
                        'source_finance_review',
                        'utility_service_review',
                        'trade_license_review',
                        'tin_review',
                        'machinery_equipment_review',
                        'raw_materials_review',
                        'ceo_info_review',
                        'director_list_review',
                        'imported_machinery_review',
                        'local_machinery_review',
                        'attachment_review',
                        'declaration_review'
                    ];

                    foreach ($review_section_array as $key => $value) {
                        if (array_search($value, $requestData['br_shortfall_review_section']) !== false) {
                            $data[$value] = 1;
                        } else {
                            $data[$value] = 0;
                        }
                    }

                    if ($data['project_status_review'] === 1) {
                        $data['commercial_operation_review'] = 1;
                    }
                    if ($data['investment_review'] === 1) {
                        $data['source_finance_review'] = 1;
                    }
                    if ($data['imported_machinery_review'] === 1) {
                        $data['local_machinery_review'] = 1;
                    }

                    BidaRegistration::where('id', $process->ref_id)->update($data);
                }
            }
            return true;
            break;

        case 106:
            if (in_array($status_id, ['9'])) {
                $ncApplication = new EtinController();
                $ncApplication->UpdateAd($process->ref_id, $requestData);
            }
            if (in_array($status_id, ['25'])) {
                CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
            }
            return true;
            break;

        case 107:
            if (in_array($status_id, ['9'])) {
                $ncApplication = new NameClearanceController();
                $ncApplication->UpdateAd($process->ref_id, $requestData);
            }
            if (in_array($status_id, ['25'])) {
                CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
            }
            return true;
            break;

        case 103:
            if (in_array($status_id, ['9'])) {
                $ncApplication = new BankAccountController();
                $ncApplication->UpdateAd($process->ref_id, $requestData);
            }
            if (in_array($status_id, ['25'])) {
                CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
            }
            return true;
            break;

        case 104:
            if (in_array($status_id, ['9'])) {
                $ncApplication = new CompanyRegistrationController();
                $ncApplication->UpdateAd($process->ref_id, $requestData);
            }
            if (in_array($status_id, ['25'])) {
                CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
            }
            return true;
            break;

        case 105:
            if (in_array($status_id, ['9'])) {
                $ncApplication = new BankAccountController();
                $ncApplication->UpdateAd($process->ref_id, $requestData);
            }
            if (in_array($status_id, ['25'])) {
                CommonFunction::sendEmailSMS('APP_APPROVE', $appInfo, $applicantEmailPhone);
            }
            return true;
            break;

        default:
            \Session::flash('error', 'Unknown process type for Certificate and Others.[PPC-1200]');
            return false;
            break;
    }// ending of switch case


} // ending of the function.


function certificateGenerationRequest($app_id, $process_type_id, $approver_desk_id = 0, $department = '', $certificate_type = 'generate')
{
    $tableName = '';
    $fieldName = '';
    switch ($process_type_id) {
        case 1: //Visa Recommendation New (1)
            $appInfo = ProcessList::leftJoin('vr_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.app_type_id as app_type_id']);
            if (empty($appInfo)) {
                return false;
            }

            // 5 = Visa On Arrival
            if ($appInfo->app_type_id == 5) {
                $pdf_info = PdfServiceInfo::where('certificate_name', 'vr_certificate_on_arrival')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else {
                $pdf_info = PdfServiceInfo::where('certificate_name', 'vr_certificate_others')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 2: //Work permit new (2)
            if ($department == 1) { //Commercial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_new_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else { //Industrial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_new_industrial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 3: //Work permit extension (3)
            if ($department == 1) { //Commercial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_extension_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else { //Industrial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_extension_industrial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 4: //Work permit amendment (4)
            if ($department == 1) { //Commercial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_amendment_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else { //Industrial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_amendment_industrial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 5: //Work permit cancellation (5)
            if ($department == 1) { //Commercial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_cancellation_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else { //Industrial
                $pdf_info = PdfServiceInfo::where('certificate_name', 'wp_cancellation_industrial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 6: // Office Permission New (6)
            // get office type of application
            $appInfo = ProcessList::leftJoin('opn_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.office_type']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->office_type == 1) { // Branch office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'opn_branch_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } elseif ($appInfo->office_type == 2) { // Liaison office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'opn_liaison_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } elseif ($appInfo->office_type == 3) { // Representative office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'opn_representative_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else {
                return false;
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 7: // Office permission extension (7)
            $appInfo = ProcessList::leftJoin('ope_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.office_type']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->office_type == 1) { // Branch office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'ope_branch_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } elseif ($appInfo->office_type == 2) { // Liaison office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'ope_liaison_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } elseif ($appInfo->office_type == 3) { // Representative office
                $pdf_info = PdfServiceInfo::where('certificate_name', 'ope_representative_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else {
                return false;
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 8: // Office permission amendment (8)
            $pdf_info = PdfServiceInfo::where('certificate_name', 'opa_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 9: // Office Permission Cancellation (9)
            $pdf_info = PdfServiceInfo::where('certificate_name', 'opc_commercial')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 10: //Visa Recommendation Amendment(10)
            $appInfo = ProcessList::leftJoin('vra_apps as app', 'app.id', '=', 'process_list.ref_id') // according new visa type
            ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.app_type_id as app_type_id']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->app_type_id == 5) {
                $pdf_info = PdfServiceInfo::where('certificate_name', 'vr_amendment_on_arrival')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else {
                $pdf_info = PdfServiceInfo::where('certificate_name', 'vr_amendment_others')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 11: //Remittance Approval new(11)
            $pdf_info = PdfServiceInfo::where('certificate_name', 'remittance_new')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 12: //Bida Registration Amendment
            $pdf_info = PdfServiceInfo::where('certificate_name', 'bida_registration_amendment')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 13: //IRC Recommendation New
            $appInfo = ProcessList::leftJoin('irc_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.irc_purpose_id as app_purpose_id']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->app_purpose_id == 1) { // 1 = raw materials
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_1st_adhoc_raw_materials')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 2) { //2 =spare parts
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_1st_adhoc_spare_parts')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 3) {// 3 = both
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_1st_adhoc_both')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 14: //IRC Recommendation 2nd adhoc
            $appInfo = ProcessList::leftJoin('irc_2nd_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.irc_purpose_id as app_purpose_id']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->app_purpose_id == 1) { // 1 = raw materials
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_2nd_adhoc_raw_materials')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 2) { //2 =spare parts
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_2nd_adhoc_spare_parts')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 3) {// 3 = both
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_2nd_adhoc_both')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 15: //IRC Recommendation 3rd adhoc
            $appInfo = ProcessList::leftJoin('irc_3rd_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.irc_purpose_id as app_purpose_id']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->app_purpose_id == 1) { // 1 = raw materials
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_3rd_adhoc_raw_materials')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 2) { //2 =spare parts
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_3rd_adhoc_spare_parts')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->app_purpose_id == 3) {// 3 = both
                $pdf_info = PdfServiceInfo::where('certificate_name', 'irc_rec_3rd_adhoc_both')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;

        case 17: //VIP Lounge
            $pdf_info = PdfServiceInfo::where('certificate_name', 'vipl_certificate')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        case 102: //BIDA Registration
            $appInfo = ProcessList::leftJoin('br_apps as app', 'app.id', '=', 'process_list.ref_id')
                ->where('process_list.ref_id', $app_id)
                ->where('process_list.process_type_id', $process_type_id)
                ->first(['app.organization_status_id']);
            if (empty($appInfo)) {
                return false;
            }

            if ($appInfo->organization_status_id === 1) { // Joint Venture
                $pdf_info = PdfServiceInfo::where('certificate_name', 'bida_registration_joint_venture')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->organization_status_id === 2) { // Foreign
                $pdf_info = PdfServiceInfo::where('certificate_name', 'bida_registration_foreign')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            } else if ($appInfo->organization_status_id === 3) { // Local
                $pdf_info = PdfServiceInfo::where('certificate_name', 'bida_registration_local')->first(['pdf_server_url', 'reg_key', 'pdf_type', 'certificate_name', 'table_name', 'field_name']);
            }

            if (empty($pdf_info)) {
                return false;
            }
            $tableName = $pdf_info->table_name;
            $fieldName = $pdf_info->field_name;
            break;
        default:
            return false;
            break;
    } // ending of switch case

    $url_store = PdfPrintRequestQueue::firstOrNew([
        'process_type_id' => $process_type_id,
        'app_id' => $app_id
    ]);

    $url_store->process_type_id = $process_type_id;
    $url_store->app_id = $app_id;
    $url_store->pdf_server_url = $pdf_info->pdf_server_url;
    $url_store->reg_key = $pdf_info->reg_key;
    $url_store->pdf_type = $pdf_info->pdf_type;
    $url_store->certificate_name = $pdf_info->certificate_name;
    $url_store->prepared_json = 0;
    $url_store->table_name = $tableName;
    $url_store->field_name = $fieldName;
    $url_store->url_requests = '';
    $url_store->job_sending_status = 0;
    $url_store->no_of_try_job_sending = 0;
    $url_store->job_receiving_status = 0;
    $url_store->no_of_try_job_receving = 0;

    if ($certificate_type == 'generate') {
        $url_store->signatory = Auth::user()->id;

        // Store approver information
        storeSignatureQRCode($process_type_id, $app_id, 0, $approver_desk_id, 'final');
    }

    $url_store->updated_at = date('Y-m-d H:i:s');
    return $url_store->save();
}


function storeSignatureQRCode($process_type_id, $app_id, $user_id = 0, $approver_desk_id, $signature_type = 'final')
{
    $pdf_sign = new \App\Modules\Settings\Models\pdfSignatureQrcode();
    $pdf_sign->signature_type = $signature_type;
    $pdf_sign->app_id = $app_id;
    $pdf_sign->process_type_id = $process_type_id;

    if ($user_id == 0) {
        $pdf_sign->signer_user_id = Auth::user()->id;
        $pdf_sign->signer_desk = CommonFunction::getDeskName($approver_desk_id);
        $pdf_sign->signer_name = CommonFunction::getUserFullName();
        $pdf_sign->signer_designation = Auth::user()->designation;
        $pdf_sign->signer_phone = Auth::user()->user_phone;
        $pdf_sign->signer_mobile = Auth::user()->user_number;
        $pdf_sign->signer_email = Auth::user()->user_email;
        $pdf_sign->signature_encode = Auth::user()->signature_encode;
    } else {
        $user_info = Users::where('id', $user_id)->first([
            DB::raw("CONCAT(user_first_name,' ',user_middle_name, ' ',user_last_name) as user_full_name"),
            'designation',
            'user_phone',
            'user_number',
            'user_email',
            'signature_encode',
        ]);
        $pdf_sign->signer_user_id = $user_id;
        $pdf_sign->signer_desk = CommonFunction::getDeskName($approver_desk_id);
        $pdf_sign->signer_name = $user_info->user_full_name;
        $pdf_sign->signer_designation = $user_info->designation;
        $pdf_sign->signer_phone = $user_info->user_phone;
        $pdf_sign->signer_mobile = $user_info->user_number;
        $pdf_sign->signer_email = $user_info->user_email;
        $pdf_sign->signature_encode = $user_info->signature_encode;
    }
    $pdf_sign->save();
}

function inspectionStore($request)
{
    $app_id = (!empty($request['app_id']) ? Encryption::decodeId($request['app_id']) : '');
    $process_list_id = (!empty($request['process_list_id']) ? Encryption::decodeId($request['process_list_id']) : '');
    $process_type_id = ProcessList::where('id', $process_list_id)->pluck('process_type_id');

    if ($process_type_id == 13) {
        $appData = new IrcInspection();
    } elseif ($process_type_id == 14) {
        $appData = new SecondIrcInspection();
    } elseif ($process_type_id == 15) {
        $appData = new ThirdIrcInspection();
    }

    $appData->app_id = $app_id;
    $appData->irc_purpose_id = $request['irc_purpose_id'];
    $appData->inspection_report_date = (empty($request['inspection_report_date']) ? '' : date('Y-m-d h:i', strtotime($request['inspection_report_date'])));
    $appData->company_name = $request['company_name'];
    $appData->office_address = $request['office_address'];
    $appData->factory_address = $request['factory_address'];
    $appData->industrial_sector = $request['industrial_sector'];
    $appData->organization_status_id = $request['organization_status_id'];
    $appData->entrepreneur_name = $request['entrepreneur_name'];
    $appData->entrepreneur_address = $request['entrepreneur_address'];
    $appData->registering_authority_name = $request['registering_authority_name'];
    $appData->registering_authority_memo_no = $request['registering_authority_memo_no'];
    $appData->reg_no = $request['reg_no'];
    $appData->date_of_registration = ($request['date_of_registration'] == '0000-00-00' ? '' : date('Y-m-d', strtotime($request['date_of_registration'])));

    $appData->local_male = $request['local_male'];
    $appData->local_female = $request['local_female'];
    $appData->local_total = $request['local_total'];
    $appData->foreign_male = $request['foreign_male'];
    $appData->foreign_female = $request['foreign_female'];
    $appData->foreign_total = $request['foreign_total'];
    $appData->manpower_total = $request['manpower_total'];
    $appData->manpower_local_ratio = $request['manpower_local_ratio'];
    $appData->manpower_foreign_ratio = $request['manpower_foreign_ratio'];

    $appData->local_land_ivst = (float)$request['local_land_ivst'];
    $appData->local_land_ivst_ccy = $request['local_land_ivst_ccy'];
    $appData->local_machinery_ivst = (float)$request['local_machinery_ivst'];
    $appData->local_machinery_ivst_ccy = $request['local_machinery_ivst_ccy'];
    $appData->local_building_ivst = (float)$request['local_building_ivst'];
    $appData->local_building_ivst_ccy = $request['local_building_ivst_ccy'];
    $appData->local_others_ivst = (float)$request['local_others_ivst'];
    $appData->local_others_ivst_ccy = $request['local_others_ivst_ccy'];
    $appData->local_wc_ivst = (float)$request['local_wc_ivst'];
    $appData->local_wc_ivst_ccy = $request['local_wc_ivst_ccy'];
    $appData->total_fixed_ivst = $request['total_fixed_ivst'];
    $appData->total_fixed_ivst_million = $request['total_fixed_ivst_million'];
    $appData->usd_exchange_rate = $request['usd_exchange_rate'];
    $appData->total_fee = $request['total_fee'];

    $appData->trade_licence_num = !empty($request['trade_licence_num']) ? $request['trade_licence_num'] : '';
    $appData->trade_licence_issue_date = (!empty($request['trade_licence_issue_date']) ? date('Y-m-d',
        strtotime($request['trade_licence_issue_date'])) : '');
    $appData->trade_licence_validity_period = !empty($request['trade_licence_validity_period']) ? $request['trade_licence_validity_period'] : "";
    $appData->trade_licence_issuing_authority = !empty($request['trade_licence_issuing_authority']) ? $request['trade_licence_issuing_authority'] : "";

    $appData->inc_number = !empty($request['inc_number']) ? $request['inc_number'] : "";
    $appData->inc_issuing_authority = !empty($request['inc_issuing_authority']) ? $request['inc_issuing_authority'] : "";

    $appData->tin_number = !empty($request['tin_number']) ? $request['tin_number'] : "";
    $appData->tin_issuing_authority = !empty($request['tin_issuing_authority']) ? $request['tin_issuing_authority'] : "";

    $appData->fl_number = isset($request['fl_number']) ? $request['fl_number'] : '';
    $appData->fl_expire_date = (!empty($request['fl_expire_date']) ? date('Y-m-d', strtotime($request['fl_expire_date'])) : '');

    $appData->fl_application_number = isset($request['fl_application_number']) ? $request['fl_application_number'] : '';

    $appData->fl_apply_date = (!empty($request['fl_apply_date']) ? date('Y-m-d', strtotime($request['fl_apply_date'])) : '');

    $appData->fl_issuing_authority = isset($request['fl_issuing_authority']) ? $request['fl_issuing_authority'] : '';;


    $appData->el_number = isset($request['el_number']) ? $request['el_number'] : '';
    $appData->el_expire_date = (!empty($request['el_expire_date']) ? date('Y-m-d', strtotime($request['el_expire_date'])) : '');

    $appData->el_application_number = isset($request['el_application_number']) ? $request['el_application_number'] : '';
    $appData->el_apply_date = (!empty($request['el_apply_date']) ? date('Y-m-d', strtotime($request['el_apply_date'])) : '');

    $appData->el_issuing_authority = isset($request['el_issuing_authority']) ? $request['el_issuing_authority'] : '';

    $appData->bank_account_number = $request['bank_account_number'];
    $appData->bank_account_title = $request['bank_account_title'];
    $appData->bank_id = $request['bank_id'];
    $appData->branch_id = $request['branch_id'];

    $appData->assoc_membership_number = !empty($request['assoc_membership_number']) ? $request['assoc_membership_number'] : "";
    $appData->assoc_chamber_name = !empty($request['assoc_chamber_name']) ? $request['assoc_chamber_name'] : "";
    $appData->assoc_issuing_date = (!empty($request['assoc_issuing_date']) ? date('Y-m-d',
        strtotime($request['assoc_issuing_date'])) : '');
    $appData->assoc_expire_date = (!empty($request['assoc_expire_date']) ? date('Y-m-d',
        strtotime($request['assoc_expire_date'])) : '');

    $appData->annual_production_start_date = !empty($request['annual_production_start_date']) ? date('Y-m-d', strtotime($request['annual_production_start_date'])) : "";
    $appData->em_lc_total_taka_mil = isset($request['em_lc_total_taka_mil']) ? $request['em_lc_total_taka_mil'] : '';
    $appData->em_local_total_taka_mil = isset($request['em_local_total_taka_mil']) ? $request['em_local_total_taka_mil'] : '';
    $appData->em_lc_total_percent = isset($request['em_lc_total_percent']) ? $request['em_lc_total_percent'] : '';
    $appData->em_lc_total_five_percent = isset($request['em_lc_total_five_percent']) ? $request['em_lc_total_five_percent'] : '';
    $appData->em_lc_total_five_percent_in_word = isset($request['em_lc_total_five_percent_in_word']) ? $request['em_lc_total_five_percent_in_word'] : '';

    $appData->project_status_id = $request['project_status_id'];
    if ($request['project_status_id'] == 4) {
        $appData->other_details = $request['other_details'];
    }

    if ($request['irc_purpose_id'] != 2) {
        $appData->apc_half_yearly_import_total = isset($request['apc_half_yearly_import_total']) ? $request['apc_half_yearly_import_total'] : 0;
        $appData->apc_half_yearly_import_total_in_word = !empty($request['apc_half_yearly_import_total_in_word']) ? $request['apc_half_yearly_import_total_in_word'] : "";
    }

    $totalFee = 0;

    //only IRC 1st adhoc has gov. fee payment
    if ($process_type_id == 13) {
        $total_import = 0;
        if ($request['irc_purpose_id'] == 1) {
            $total_import = (isset($request['apc_half_yearly_import_total']) ? $request['apc_half_yearly_import_total'] : 0) * 2;
        } elseif ($request['irc_purpose_id'] == 2) {
            $total_import = (isset($request['em_lc_total_five_percent']) ? $request['em_lc_total_five_percent'] : 0) * 2;
        } else {
            $total_import = ((isset($request['apc_half_yearly_import_total']) ? $request['apc_half_yearly_import_total'] : 0) + (isset($request['em_lc_total_five_percent']) ? $request['em_lc_total_five_percent'] : 0)) * 2;
        }

        //Govt. fee calculation on half yearly import
        $total = DB::select("select * from irc_inspection_gov_fee_range where annual_total_import_min <= $total_import and annual_total_import_max >= $total_import and status = 1 and is_archive = 0");


        if ($request['app_type'] == 1 && !empty($total)) {
            $totalFee = $total[0]->primary_reg_fee;
        }else if ($total_import >= '50000001') {
            $totalFee = '60000';
        }
    }

    $appData->inspection_gov_fee = $totalFee;
    $appData->remarks = $request['irc_remarks'];
    $appData->entitlement_remarks = $request['entitlement_remarks'];

    //Inspection officer info
    $appData->io_name = CommonFunction::getUserFullName();
    $appData->io_designation = Auth::user()->designation;
    $appData->io_mobile_no = Auth::user()->user_phone;
    $appData->io_email = Auth::user()->user_email;
    $appData->io_signature = Auth::user()->signature;

    $appData->save();

    if ($process_type_id === 13) {
        IrcRecommendationNew::where('id', $app_id)->update(['inspection_gov_fee' => $totalFee]);
    } elseif ($process_type_id === 14) {
        IrcRecommendationSecondAdhoc::where('id', $app_id)->update(['inspection_gov_fee' => $totalFee]);
    } elseif ($process_type_id === 15) {
        IrcRecommendationThirdAdhoc::where('id', $app_id)->update(['inspection_gov_fee' => $totalFee]);
    }

    // Annual production capacity
    if (!empty($appData->id) && !empty($request['product_name'][0])) {
        if ($process_type_id == 13) {
            InspectionAnnualProduction::where('app_id', $appData->id)->delete();
        } elseif ($process_type_id == 14) {
            SecondInspectionAnnualProduction::where('app_id', $appData->id)->delete();
        } elseif ($process_type_id == 15) {
            ThirdInspectionAnnualProduction::where('app_id', $appData->id)->delete();
        }

        foreach ($request['product_name'] as $proKey => $proData) {
            if ($process_type_id == 13) {
                $annualCap = new InspectionAnnualProduction();
            } elseif ($process_type_id == 14) {
                $annualCap = new SecondInspectionAnnualProduction();
            } elseif ($process_type_id == 15) {
                $annualCap = new ThirdInspectionAnnualProduction();
            }
            $annualCap->app_id = $app_id;
            $annualCap->inspection_id = $appData->id;
            $annualCap->product_name = $request['product_name'][$proKey];
            $annualCap->unit_of_product = isset($request['unit_of_product'][$proKey]) ? $request['unit_of_product'][$proKey] : '';
            $annualCap->quantity_unit = isset($request['quantity_unit'][$proKey]) ? $request['quantity_unit'][$proKey] : '';
            $annualCap->fixed_production = $request['fixed_production'][$proKey];
            $annualCap->half_yearly_production = $request['half_yearly_production'][$proKey];
            $annualCap->half_yearly_import = $request['half_yearly_import'][$proKey];
            $annualCap->raw_material_total_price = isset($request['raw_material_total_price'][$proKey]) ? $request['raw_material_total_price'][$proKey] : '';
            $annualCap->save();
        }
    }
//        Session::flash('success', 'Successfully Application Submitted !');
    return true;
}