<?php 

return [
    'welcome' => 'Welcome, this is ProcessPath module.'
];
