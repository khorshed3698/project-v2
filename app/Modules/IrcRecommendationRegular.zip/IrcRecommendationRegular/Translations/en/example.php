<?php 

return [
    'welcome' => 'Welcome, this is BidaRegistration module.'
];
